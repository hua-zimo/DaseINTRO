# coding=utf-8
import requests
import csv
if __name__ == "__main__":
    post_url = 'https://movie.douban.com/j/chart/top_list'
    headers = {
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36 Edg/95.0.1020.40'
    }
    param = {
        'type': '17', # 电影类型
        'interval_id': '100:90',
        'action':'',
        'start': 0,    #从第几部电影开始去取
        'limit': 182,       #一次取多少个
    }
    reps = requests.get(url=post_url,params=param,headers=headers)
    list_data = reps.json()
    #创建空字典存储爬取数据
    dic = {}
    #创建csv文件存储
    f = open("电影榜单.csv", mode='w', newline='', encoding='utf-8')
    csvwriter = csv.writer(f)
    csvwriter.writerow(['排名','电影','网址','评分'])

    #for循环从列表中提取字典的键值
    for dicnum in list_data:
        dic['排名'] = dicnum['rank']
        dic['电影名'] = dicnum['title']
        dic['url'] = dicnum['url']
        dic['评分'] = dicnum['score']
        print(dic)
        csvwriter.writerow(dic.values())
    f.close()
 
    print('----over!!------')