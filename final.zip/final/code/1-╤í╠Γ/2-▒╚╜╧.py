import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 读取剧情电影榜单CSV文件
drama_data = pd.read_csv('剧情电影榜单.csv')

# 读取科幻电影榜单CSV文件
sci_fi_data = pd.read_csv('科幻电影榜单.csv')

# 设置图形风格
sns.set(style='whitegrid')

# 画出电影评分的分布图
plt.figure(figsize=(12, 6))
sns.histplot(drama_data['评分'], kde=True, color='orange', label='Drama')
sns.histplot(sci_fi_data['评分'], kde=True, color='blue', label='Sci-Fi')

# 设置图形属性
plt.title('Movie Rating Distribution Chart')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.legend()

# 显示图形
plt.show()

