import re
import requests
import csv
from lxml import etree

class wert(object):

    # 创建编号文件
    file = open('编号.csv', 'a', newline='', encoding='utf-8-sig')
    write = csv.writer(file)

    def __init__(self):

        self.headers = {
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer':'https://movie.douban.com/typerank?type_name=%E7%A7%91%E5%B9%BB&type=17&interval_id=100:90&action=',
            'Cookie':'bid=fXh3tiHb2zo; _ga_RXNMP372GL=GS1.1.1687533043.1.1.1687533052.51.0.0; _pk_id.100001.4cf6=e3a470da9c31bf12.1687533068.; __utmz=223695111.1687533073.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __yadk_uid=xYD7YA2u5c2uEBrhIjUb1KURqZEjUqeG; _vwo_uuid_v2=D5279752C9C78D1FA069292B8B77A8B64|af623eda2c85ce065dfb32820b548ee6; _ga=GA1.1.293791524.1686386512; _ga_Y4GN1R87RG=GS1.1.1687533209.1.0.1687533216.0.0.0; __gads=ID=58031ef0c9fcd740-222b2d60cbe10015:T=1687533269:RT=1687533269:S=ALNI_MYt2A_X-QEkWDd5N1rf70wbDbjELQ; __gpi=UID=00000c6290bd4c2b:T=1687533269:RT=1687533269:S=ALNI_Mbe8fcBPVvI0K4VrVmgNqkEOTSqrQ; ll="108288"; douban-fav-remind=1; __utmz=30149280.1693911188.4.2.utmcsr=baidu|utmccn=(organic)|utmcmd=organic'
        }
        self.requestt()

    def requestt(self):

        num = 0
        # 设置json页码规律
        for page in range(10):
            url = 'https://movie.douban.com/j/chart/top_list?type=17&interval_id=100%3A90&action=&start={}&limit=20'.format(num)
            num += 20

            self.responsee = requests.get(url, headers=self.headers)

            self.parse()

    def parse(self):

        print(self.responsee.json())

        for i in self.responsee.json():
            # 获取连接
            keynum = i['url']
            # 提取编码
            keynum = re.findall('https://movie.douban.com/subject/(\d+)/', keynum)[0]

            self.write.writerow([keynum])

if __name__ == '__main__':


    run = wert()
