import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# 读取CSV文件
train_df = pd.read_csv("评分者观影历史.csv")

# 准备特征和目标变量，并进行缺失值处理
X = train_df[["科幻电影历史平均评分"]].fillna(train_df["科幻电影历史平均评分"].mean())
y = train_df["当前科幻电影评分"]

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 创建线性回归模型，设置fit_intercept为False
linear_model_no_intercept = LinearRegression(fit_intercept=False)

# 训练模型
linear_model_no_intercept.fit(X_train, y_train)

# 在测试集上进行预测
y_pred_no_intercept = linear_model_no_intercept.predict(X_test)

# 计算均方误差
mse_no_intercept = mean_squared_error(y_test, y_pred_no_intercept)

# 获取线性回归模型的系数
slope_no_intercept = linear_model_no_intercept.coef_[0]

# 打印线性关系的公式
print(f"线性关系公式（不含截距项）: y = {slope_no_intercept} * X")

# 打印均方误差
print("线性回归模型（不含截距项）均方误差:", mse_no_intercept)

