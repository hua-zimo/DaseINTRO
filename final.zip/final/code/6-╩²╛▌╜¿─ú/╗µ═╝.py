import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import matplotlib

# 设置中文字体
font = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=12)  # 修改为你系统中的中文字体路径
matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 设置全局中文字体

# 读取CSV文件
df = pd.read_csv("result.csv")

# 提取需要比较的列
current_rating = df["当前科幻电影评分"]
weighted_rating = df["观影历史加权评分"]

# 创建图表
plt.figure(figsize=(10, 6))

# 绘制柱状图
plt.bar(df.index, current_rating, width=0.4, label="当前科幻电影评分", align="edge")
plt.bar(df.index, weighted_rating, width=-0.4, label="观影历史加权评分", align="edge")

# 添加标签和标题
plt.xlabel("观众编号", fontproperties=font)
plt.ylabel("评分", fontproperties=font)
plt.title("当前科幻电影评分 vs. 观影历史加权评分", fontproperties=font)
plt.legend()

# 显示图表
plt.show()
