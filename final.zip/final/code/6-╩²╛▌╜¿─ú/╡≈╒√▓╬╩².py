import pandas as pd
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Lasso
from sklearn.metrics import make_scorer, mean_squared_error

# 读取CSV文件
train_df = pd.read_csv("评分者观影历史.csv")

# 创建Lasso回归模型
lasso_model = Lasso()

# 定义观影历史权重系数 alpha 的取值范围
alphas = [0.1, 0.2, 0.3, 0.4, 0.5]

# 创建参数网格
param_grid = {'alpha': alphas}

# 创建均方误差评分对象
mse_scorer = make_scorer(mean_squared_error)

# 创建 GridSearchCV 对象
grid_search = GridSearchCV(lasso_model, param_grid, scoring=mse_scorer, cv=5)

# 准备特征和目标变量，并进行缺失值出现的异常处理
X = train_df[["科幻电影历史平均评分"]].fillna(train_df["科幻电影历史平均评分"].mean())
y = train_df["当前科幻电影评分"]

# 执行网格搜索
grid_search.fit(X, y)

# 打印最佳参数和对应的均方误差
print("最佳参数:", grid_search.best_params_)
print("最佳均方误差:", grid_search.best_score_)






