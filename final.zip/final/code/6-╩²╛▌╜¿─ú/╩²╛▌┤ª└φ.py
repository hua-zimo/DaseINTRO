import pandas as pd

# 读取CSV文件
df = pd.read_csv('merged_file.csv')

# 删除总电影数量为0的行
df = df[df['总电影数量'] != 0]

# 保存修改后的CSV文件
df.to_csv('星际穿越_数据.csv', index=False)
