import pandas as pd

# 读取CSV文件
df = pd.read_csv("评分者观影历史.csv")

# 设置观影历史权重系数
alpha = 0.1

# 计算观影历史加权评分
df["观影历史加权评分"] = (1 - alpha) * df["当前科幻电影评分"] + alpha * (df["科幻电影历史平均评分"])

# 保存结果到CSV文件
df.to_csv("result.csv", index=False)

