import pandas as pd
import numpy as np

# 读取CSV文件
df = pd.read_csv("评分者观影历史.csv")

# 生成随机评分列
df["当前科幻电影评分"] = np.random.randint(3, 6, size=len(df))

# 将DataFrame写入新的CSV文件
df.to_csv("评分者观影历史.csv", index=False)



