import pandas as pd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

# 读取CSV文件
df = pd.read_csv('评分者观影历史.csv')

# 设置图形大小
plt.figure(figsize=(12, 6))

# 散点图 - 科幻观影数量 vs 科幻电影历史平均评分，细分横轴
plt.subplot(1, 2, 1)
plt.scatter(df['科幻类别观影数量'], df['科幻电影历史平均评分'], c=df['总观影数量'], cmap='Blues', alpha=0.7)
plt.title('科幻观影数量 vs 科幻电影历史平均评分')
plt.xlabel('科幻观影数量')
plt.ylabel('科幻电影历史平均评分')
plt.colorbar(label='总观影数量')

# 散点图 - 总观影数量 vs 科幻电影历史平均评分，细分横轴
plt.subplot(1, 2, 2)
plt.scatter(df['总观影数量'], df['科幻电影历史平均评分'], c=df['科幻类别观影数量'], cmap='Blues', alpha=0.7)
plt.title('总观影数量 vs 科幻电影历史平均评分')
plt.xlabel('总观影数量')
plt.ylabel('科幻电影历史平均评分')
plt.colorbar(label='科幻观影数量')

# 调整布局
plt.tight_layout()

# 显示图形
plt.show()


