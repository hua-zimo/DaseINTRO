import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体
font = FontProperties(fname=r'C:\Windows\Fonts\simhei.ttf', size=12)  

# 读取CSV文件，指定日期格式
df = pd.read_csv('your_modified_短评.csv', parse_dates=['时间'], date_format='%Y-%m-%d%H:%M:%S', on_bad_lines='skip')

# 将时间列转换为日期类型（如果尚未解析为datetime）
df['时间'] = pd.to_datetime(df['时间'], format='%Y-%m-%d%H:%M:%S', errors='coerce')

# 提取年份信息
df['年份'] = df['时间'].dt.to_period('Y')

# 统计每个年份的评论数量
heatmap_data = df['年份'].value_counts().sort_index()

# 保存结果到CSV文件
heatmap_data.to_csv('评论数量按年份统计.csv', header=['评论数量'])

# 创建热力图
plt.figure(figsize=(12, 8))
sns.heatmap(pd.DataFrame(heatmap_data), cmap='Blues', annot=True, fmt=".0f", linewidths=.5)

plt.title('评论数量按年份统计热力图', fontproperties=font)
plt.xlabel('评论数量', fontproperties=font)  # 更改为适当的X轴标签
plt.ylabel('年份', fontproperties=font)  # 更改为适当的Y轴标签

plt.show()





