import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像时负号'-'显示为方块的问题

# 假设数据保存在一个CSV文件中，读取数据集
df = pd.read_csv('评分者观影历史.csv')

# 设置图表样式
sns.set(style="whitegrid")

# 绘制柱状图，表示每列的平均值
plt.figure(figsize=(12, 6))
sns.barplot(x=df.columns, y=df.mean())
plt.title('平均值')
plt.show()

# 绘制箱线图，表示每列的分布
plt.figure(figsize=(12, 6))
sns.boxplot(data=df)
plt.title('分布')
plt.show()

# 绘制热力图，表示各列之间的相关性
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', fmt=".2f")
plt.title('相关性热力图')
plt.show()
