import pandas as pd

# 读取CSV文件
df = pd.read_csv('data.csv')

# 删除最后一列
df = df.iloc[:, :-1]

# 计算第二列除以第一列的结果并添加到DataFrame中
df['科幻电影历史平均评分'] = df['科幻电影历史评分'] / df['科幻类别观影数量']

# 保存修改后的数据到新的CSV文件
df.to_csv('评分者观影历史.csv', index=False)

