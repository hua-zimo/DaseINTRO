import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体
font = FontProperties(fname=r'C:\Windows\Fonts\simhei.ttf', size=8)  

# 读取CSV文件
df = pd.read_csv('cleaned_data.csv', on_bad_lines='skip', infer_datetime_format=True)

# 移除"无"地区
df = df[df['地区'] != '无']

# 计算地区分布
region_distribution = df['地区'].value_counts()

# 将占比小于某个阈值的地区合并为"其他"
threshold = 0.02  # 设置合并的阈值，可以根据需要调整
small_regions = region_distribution[region_distribution / region_distribution.sum() < threshold].index
df['地区'] = df['地区'].apply(lambda x: '其他' if x in small_regions else x)

# 重新计算合并后的地区分布
region_distribution = df['地区'].value_counts()

# 获取不同占比的蓝色
colors = plt.cm.Blues(region_distribution / region_distribution.max())

# 饼状图，占比写在图内，数量写在地区名字后面的括号里
plt.figure(figsize=(8, 8))

# 添加数量和占比信息到标签中
labels = [f'{label}\n{count / region_distribution.sum() * 100:.1f}%({count})' for label, count in zip(region_distribution.index, region_distribution.values)]

plt.pie(region_distribution, labels=labels, startangle=140, textprops={'fontproperties': font}, colors=colors)
plt.title('用户地区分布', fontproperties=font)
plt.show()
