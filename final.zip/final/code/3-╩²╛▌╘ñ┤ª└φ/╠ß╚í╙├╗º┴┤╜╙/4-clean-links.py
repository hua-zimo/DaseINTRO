import pandas as pd

# 读取CSV文件，使用on_bad_lines参数代替error_bad_lines
df = pd.read_csv('用户链接_新形式.csv', on_bad_lines='skip')

# 删除重复的行（基于用户链接列）
df.drop_duplicates(subset='用户链接', keep='first', inplace=True)

# 保存修改后的数据到新的CSV文件
df.to_csv('clean_用户链接_新形式.csv', index=False)