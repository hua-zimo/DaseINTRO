import pandas as pd
import re

# 读取包含用户链接的CSV文件，并删除包含NaN值的行
df_movie_comments = pd.read_csv('用户链接_去除中文.csv', on_bad_lines='skip').dropna(subset=['用户链接'])

# 定义函数将原始链接替换为新链接
def modify_user_url(original_url):
    # 提取用户名
    username = re.search(r'/people/([^/]+)/', original_url).group(1)
    # 构建新链接
    modified_url = f'https://movie.douban.com/people/{username}/collect?start={{}}&sort=time&rating=all&filter=all&mode=grid'
    return modified_url

# 将用户链接列的值修改为新链接
df_movie_comments['用户链接'] = df_movie_comments['用户链接'].apply(modify_user_url)

# 保存结果到新的CSV文件
df_movie_comments.to_csv('用户链接_新形式.csv', index=False)

