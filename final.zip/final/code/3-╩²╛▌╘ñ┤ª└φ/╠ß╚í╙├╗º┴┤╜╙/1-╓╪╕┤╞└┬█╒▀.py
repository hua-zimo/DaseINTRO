import pandas as pd

# 读取CSV文件，使用on_bad_lines参数代替error_bad_lines
df = pd.read_csv('短评.csv', on_bad_lines='skip')

# 删除重复的行（基于用户链接列）
df.drop_duplicates(subset='用户链接', keep='first', inplace=True)

# 删除第一列元素为"当"的行
df = df[df.iloc[:, 0] != '当']

# 保存修改后的数据到新的CSV文件
df.to_csv('cleaned_data.csv', index=False)
