import pandas as pd
import re

# 读取原始 CSV 文件
df = pd.read_csv('cleaned_data.csv', on_bad_lines='skip')

# 定义函数去除中文字符
def remove_chinese(text):
    chinese_removed = re.sub(r'[\u4e00-\u9fa5]', '', str(text))  # 使用正则表达式去除中文字符
    return chinese_removed

# 去除用户链接列的中文字符
df['用户链接'] = df['用户链接'].apply(remove_chinese)

# 保存用户链接列到新的 CSV 文件
df[['用户链接']].to_csv('用户链接_去除中文.csv', index=False)



