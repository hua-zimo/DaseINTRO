import pandas as pd

# 读取CSV文件
df = pd.read_csv('cleaned_data.csv', on_bad_lines='skip', infer_datetime_format=True)

# 移除"无"地区
df = df[df['地区'] != '无']

# 计算地区分布
region_distribution = df['地区'].value_counts()

# 将占比小于某个阈值的地区合并为"其他"
threshold = 0.02  # 设置合并的阈值，可以根据需要调整
small_regions = region_distribution[region_distribution / region_distribution.sum() < threshold].index
df['地区'] = df['地区'].apply(lambda x: '其他' if x in small_regions else x)

# 重新计算合并后的地区分布
region_distribution = df['地区'].value_counts()

# 计算各个地区的占比
region_percentage = region_distribution / region_distribution.sum() * 100

# 创建包含地区、地区数量和地区占比的DataFrame
result_df = pd.DataFrame({'地区': region_distribution.index, '地区数量': region_distribution.values, '地区占比': region_percentage.values})

# 将结果保存到CSV文件
result_df.to_csv('region_distribution.csv', index=False)
