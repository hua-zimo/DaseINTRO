import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = 'SimHei'  # 设置中文显示
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 读取归一化后的数据
normalized_data = pd.read_csv('评分者观影历史_归一化.csv')

# 绘制散点图
plt.scatter(normalized_data['科幻类别观影数量_normalized'], normalized_data['总观影数量_normalized'])
plt.title('观影历史归一化数据')
plt.xlabel('科幻观影数量')
plt.ylabel('总观影数量')
plt.show()
