import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用中文黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 读取CSV文件
df = pd.read_csv("评分者观影历史_归一化.csv")

# 选择需要拟合的特征
X = df["科幻观影数量"].values.reshape(-1, 1)

# 选择目标变量
y = df["总观影数量"].values

# 创建线性回归模型
model = LinearRegression()

# 拟合模型
model.fit(X, y)

# 预测
y_pred = model.predict(X)

# 获取线性拟合的系数和截距
coefficient = model.coef_[0]
intercept = model.intercept_

# 打印线性拟合的模型
print(f"线性拟合模型：y = {coefficient:.4f} * x + {intercept:.4f}")

# 绘制散点图和蓝色拟合直线
plt.scatter(X, y, label="观众数据")
plt.plot(X, y_pred, color='blue', linewidth=2, label="线性拟合")

plt.xlabel("科幻观影数量")
plt.ylabel("总观影数量")
plt.legend()
plt.show()

