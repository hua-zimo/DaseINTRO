import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 设置中文字体
font_path = "C:/Windows/Fonts/simhei.ttf"  # 请根据实际路径选择合适的中文字体文件
font_prop = fm.FontProperties(fname=font_path)
plt.rcParams['font.sans-serif'] = ['SimHei']

# 读取第一个CSV文件
file1_data = pd.read_csv('评分者观影历史_归一化.csv')
# 选择需要合并的列
data1_selected_columns = file1_data[['科幻观影数量', '科幻电影历史评分', '总观影数量']]

# 读取第二个CSV文件
file2_data = pd.read_csv('评分者观影历史.csv')
# 选择需要合并的列
data2_selected_columns = file2_data[['科幻电影历史平均评分']]

# 将两个数据框合并
merged_data = pd.concat([data1_selected_columns, data2_selected_columns], axis=1)

# 绘制热力图
sns.heatmap(merged_data.corr(), annot=True, cmap='coolwarm', fmt=".2f")

# 显示图形
plt.show()


