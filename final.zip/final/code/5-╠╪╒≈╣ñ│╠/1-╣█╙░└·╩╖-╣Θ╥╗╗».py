import pandas as pd

# 读取原始数据
data = pd.read_csv('评分者观影历史.csv')

# 提取需要归一化的两列数据
sci_fi_views = data['科幻类别观影数量']
sci_fi_rates = data['科幻电影历史评分']
total_views = data['总观影数量']

# Min-Max 归一化
sci_fi_views_normalized = (sci_fi_views - sci_fi_views.min()) / (sci_fi_views.max() - sci_fi_views.min())
sci_fi_rates_normalized = (sci_fi_rates - sci_fi_rates.min()) / (sci_fi_rates.max() - sci_fi_rates.min())
total_views_normalized = (total_views - total_views.min()) / (total_views.max() - total_views.min())

# 创建新的 DataFrame 存储归一化后的数据
normalized_data = pd.DataFrame({'科幻类别观影数量_normalized': sci_fi_views_normalized,
                                '科幻电影历史评分_normalized': sci_fi_rates_normalized,
                                 '总观影数量_normalized': total_views_normalized})

# 将结果写入 CSV 文件
normalized_data.to_csv('评分者观影历史_归一化.csv', index=False)
