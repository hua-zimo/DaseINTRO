import requests
import csv
from lxml import etree
import time
import re

# 创建文件
class UTY(object):

    def __init__(self):
        # 读取编号文件
        file = open('编号.csv', 'r', encoding='utf-8-sig', newline='')
        reader = csv.reader(file)
        # 创建短评文件
        file2 = open('短评.csv', 'w', encoding='utf-8-sig', newline='')
        self.write = csv.writer(file2)
        # 写入表头
        self.write.writerow(['用户链接', '用户名', '星级', '评论内容', '时间', '有用数', '地区'])
        self.headers = {
            # 设置伪装，注意cookie
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36',
            'Cookie': 'bid=oromBooD0_Q; __gads=ID=1e85c8ee63650842-228f5a192cd8004f:T=1668070627:RT=1668070627:S=ALNI_Ma'
                      '-VyKUTowf1DjoTDJf46UFOo2SMw; ll="118239"; _vwo_uuid_v2=DA606354E9B3059079B0A80121E680FA8|1da6fcad'
                      'd0240429d4c76383d0fd8ac8; __yadk_uid=MN1fofXEXpqiYVmrSnMXzEwX9wbdhJDw; _ga=GA1.2.1502290086.16680'
                      '70626; _gid=GA1.2.1489211089.1678626675; ct=y; Hm_lvt_16a14f3002af32bf3a75dfe352478639=1677382721,'
                      '1678681634; ap_v=0,6.0; __utmc=30149280; __utmc=223695111; __gpi=UID=00000b791963664a:T=1668070627:'
                      'RT=1678706730:S=ALNI_MZXHMu7DdUDIXxqVyOF6XPIhnMmmg; _pk_ref.100001.4cf6=%5B%22%22%2C%22%22%2C167871'
        }
        
        a = 0
        # 遍历编号文件中的数据
        for l in reader:
            print('当前编号数{}'.format(a))
            self.write.writerow(['当前编号数{}'.format(a)])
            a += 1
            print(l[0])
            
            # 从好评、差评等不同页面获取评价，保证数据的多样性
            for page in range(3):
                if page == 0:
                    num = 0
                    for i in range(3):
                        # 构建URL，获取好评页面评论
                        url = 'https://movie.douban.com/subject/{}/comments?percent_type=h&start={}&limit=200&status=P&sort=new_score'.format(l[0], num)
                        num += 200
                        self.parse(url)
                elif page == 1:
                    num = 0
                    for i in range(3):
                        # 构建URL，获取中评页面评论
                        url = 'https://movie.douban.com/subject/{}/comments?percent_type=m&start={}&limit=200&status=P&sort=new_score'.format(l[0], num)
                        num += 200
                        self.parse(url)
                elif page == 2:
                    num = 0
                    for i in range(3):
                        # 构建URL，获取差评页面评论
                        url = 'https://movie.douban.com/subject/{}/comments?percent_type=i&start={}&limit=200&status=P&sort=new_score'.format(
                            l[0], num)
                        num += 200
                        self.parse(url)

    def parse(self, url):
        # 发送HTTP请求获取页面内容
        response = requests.get(url, headers=self.headers)
        aimtext = response.text
        text = etree.HTML(aimtext)
        # 获取所有用户数据
        # 遍历评论区域
        text = text.xpath('//div[@id="comments"]/div')[:-1]
        for item in text:
            try:
                # 提取用户链接、用户名、有用数、评论内容等信息
                link = item.xpath('.//h3/span[2]/a/@href')[0]
                name = item.xpath('.//h3/span[2]/a/text()')[0]
                youyongshu = item.xpath('.//h3/span[1]/span/text()')[0] + '有用'
                content = item.xpath('.//span[@class="short"]/text()')[0]
                content = re.sub('[\n\t\r\s]', '', content)
                try:
                    xing = item.xpath('.//h3/span[2]/span[contains(@class, "rating")]/@class')[0].split(' ')[0][-2]
                    xingji = item.xpath('.//h3/span[2]/span[contains(@class, "rating")]/@title')[0] + '(' + xing + '星'+ ")"
                except:
                    xingji = '无'
                time = item.xpath('.//h3/span[2]/span[@class="comment-time "]/text()')[0]
                time = re.sub('[\s\t\n\r]', '', time)
                try:
                    region = item.xpath('.//h3/span[2]/span[@class="comment-location"]/text()')[0]
                    region = re.sub('[\s\r\t\n]', '', region)
                except:
                    region = '无'
                region = re.sub('[\s\r\t\n]', '', region)
                # 输出信息并写入文件
                print(link, name, xingji, content, time, youyongshu, region)
                self.write.writerow([link, name, xingji, content, time, youyongshu, region])
            except:
                continue

if __name__ == '__main__':
    # 实例化并运行
    runer = UTY()
    # pass
