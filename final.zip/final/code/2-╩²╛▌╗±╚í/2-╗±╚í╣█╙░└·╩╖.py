import requests
import csv
from lxml import etree
import time
import re
import random

# 创建文件
class UTY(object):    

    def __init__(self):
        # 读取代理IP列表
        self.proxies = self.load_proxies('ip.txt')

        file = open('links_1.csv', 'r', encoding='utf-8-sig', newline='')
        reader = csv.reader(file)
        
        # 创建一个新的CSV文件，用于存储所有短评数据
        file2 = open('history_data.csv', 'w', encoding='utf-8-sig', newline='')
        self.write = csv.writer(file2)
        
        # 写入表头
        self.write.writerow(['用户id', '科幻电影数量', '科幻电影评分', '总电影数量', '总电影评分'])
        
        # 设置请求头信息
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Cookie': 'bid=fXh3tiHb2zo; _ga_RXNMP372GL=GS1.1.1687533043.1.1.1687533052.51.0.0; _pk_id.100001.4cf6=e3a470da9c31bf12.1687533068.; __utmz=223695111.1687533073.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __yadk_uid=xYD7YA2u5c2uEBrhIjUb1KURqZEjUqeG; _vwo_uuid_v2=D5279752C9C78D1FA069292B8B77A8B64|af623eda2c85ce065dfb32820b548ee6; _ga=GA1.1.293791524.1686386512; _ga_Y4GN1R87RG=GS1.1.1687533209.1.0.1687533216.0.0.0; __gads=ID=58031ef0c9fcd740-222b2d60cbe10015:T=1687533269:RT=1687533269:S=ALNI_MYt2A_X-QEkWDd5N1rf70wbDbjELQ; __gpi=UID=00000c6290bd4c2b:T=1687533269:RT=1687533269:S=ALNI_Mbe8fcBPVvI0K4VrVmgNqkEOTSqrQ; ll="108288"; douban-fav-remind=1; __utmz=30149280.1693911188.4.2.utmcsr=baidu|utmccn=(organic)|utmcmd=organic'
        }
        
        a = 0
        # 遍历输入csv文件中每一个用户链接
        for l in reader:
            print('当前用户{}'.format(a))
            self.all_(l[0])
            a += 1
            
            time.sleep(random.randint(3, 8))
            
    def load_proxies(self, file_path):
        # 从文件中读取代理IP列表
        with open(file_path, 'r') as file:
            proxies = file.read().splitlines()
        return proxies

    def all_(self, url):
        url_template = str(url)
        first_url = url_template.format(0)
        print(first_url)
        
        total_movies_count = self.get_movie_count(first_url)
        if total_movies_count is None:
            return 0, 0, 0, 0
    
        print(f"总电影数量：{total_movies_count}")
        movies_per_page = 15
        total_pages = (total_movies_count + movies_per_page - 1) // movies_per_page
        total_movies_page = total_pages * 15
        
        count_sum = 0
        rating_sum = 0
        total_movies_rating = 0
    
        for i in range(0, total_movies_page, 15):  # 从 start=0 开始，间隔为 15
            # 使用字符串的格式化将 {} 替换为当前的数字
            new_url = url_template.format(i)
            # print(i)
        
            new_count, new_rating, new_movie_rating = self.get_sci_fi_movie(new_url)
            count_sum += new_count
            rating_sum += new_rating
            total_movies_rating += new_movie_rating
    
        print(count_sum, rating_sum, total_movies_count, total_movies_rating, sep=', ')
        return count_sum, rating_sum, total_movies_count, total_movies_rating

    def get_movie_count(self, url):
        try:
            proxy = random.choice(self.proxies)
            # 发送HTTP请求以获取评论页面的内容
            response = requests.get(url, headers=self.headers, proxies={'http': proxy, 'https': proxy})
            print(f"Response Status Code: {response.status_code}")  # 添加这一行
            aimtext = response.text
            text = etree.HTML(aimtext)
            
            if text is None:
                print("未成功获取到 text 对象")
                return None
            
            # 提取包含已观看电影数量的字段
            movie_count_element = text.xpath('//title/text()')
            if movie_count_element:
                movie_count_text = movie_count_element[0]
                # 用正则式提取数字
                match = re.search(r'\((\d+)\)', movie_count_text)
                
                if match:
                    movie_count = int(match.group(1))
                    print(f"提取到的数字：{movie_count}")
                    return movie_count
                
        except Exception as e:
            print(f"发生异常：{e}")
        
        return None
    
    def get_sci_fi_movie(self, url):
        # time.sleep(random.randint(1, 3))
        proxy = random.choice(self.proxies)
        # 发送HTTP请求以获取评论页面的内容
        response = requests.get(url, headers=self.headers, proxies={'http': proxy, 'https': proxy})
        # print(f"Response Status Code: {response.status_code}")  # 添加这一行
        aimtext = response.text
        text = etree.HTML(aimtext)
    
        # 在用户的收藏页面找到所有电影条目
        movie_items = text.xpath('//div[@class="item comment-item"]')
    
        # 初始化科幻电影的数量和评分、总电影评分
        sci_fi_movie_count = 0
        sci_fi_movie_rating = 0
        movie_rating = 0
        movie_count = 0
        
        for movie_item in movie_items:
            try:
                movie_count += 1

                # 找到评分标签
                rating_tags = movie_item.xpath('.//span[contains(@class, "rating") and contains(@class, "t")]/@class')

            # 检查是否找到评分标签
                if rating_tags:
                    rating_value = int(re.search(r'\d+', ' '.join(rating_tags)).group())
                    # 将评分添加到总数
                    movie_rating += rating_value
            
                    # 使用 XPath 表达式获取电影名字和判断是否为科幻电影
                    title_element = movie_item.xpath('.//li[@class="title"]/a/em/text()')[0]
                    genre = movie_item.xpath('.//li[@class="intro"]/text()')[0]
            
                    # 判断是否包含 "科幻"
                    is_sci_fi = "科幻" in genre
                    # 打印结果
                    if is_sci_fi:
                        sci_fi_movie_count += 1
                        sci_fi_movie_rating += rating_value
                # print(f"这是一部科幻电影，电影名字是：{title_element}")
            # else:
                # print("这不是一部科幻电影")
            except:
                continue
        return sci_fi_movie_count, sci_fi_movie_rating, movie_rating

if __name__ == '__main__':
    runer = UTY()
